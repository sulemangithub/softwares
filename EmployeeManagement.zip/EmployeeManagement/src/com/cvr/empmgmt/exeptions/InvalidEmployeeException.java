package com.cvr.empmgmt.exeptions;

public class InvalidEmployeeException extends Exception{
	
	public InvalidEmployeeException(String message) {
		super(message);
	}
}
